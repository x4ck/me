Set-ExecutionPolicy Unrestricted -Scope CurrentUser
ls -Recurse *.ps*1 | Unblock-File
scripts\remove-default-apps.ps1
scripts\optimize-user-interface.ps1

.\cleaner.ps1

.\choco.ps1
choco install curl git python wget -y
.\pip.cmd

cd .\foots\
C:\Python38\python.exe .\generate_fingerprint.py --telemetry --network --hardware
cd ..\fonts\
C:\Python38\python.exe .\font_fingerprint.py 19
cd ..\

choco install chromium ungoogled-chromium -y
.\firefox.exe
choco install opera -y
choco install 7zip -y
choco install anydesk -y
choco install notepadplusplus -y
choco install far -y
choco install powershell-preview -y
.\Default.cmd
explorer.exe .\unkn0wn.theme

.\KMS_VL_ALL_AIO.cmd

.\1803_VDI_Configuration.ps1
