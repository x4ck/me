Set-ExecutionPolicy Unrestricted -Scope CurrentUser
ls -Recurse *.ps*1 | Unblock-File
scripts\remove-default-apps.ps1
scripts\optimize-user-interface.ps1

Set-ExectionPolicy Bypass -Force
.\cleaner.ps1
.\scoop.ps1

pip3 install pproxy asyncio asyncssh pycryptodome

cd .\foots\
python .\generate_fingerprint.py --telemetry --network --hardware
cd ..\fonts\
python .\font_fingerprint.py 19
cd ..\

.\choco.ps1
choco install office365homepremium -y
.\Activate.cmd
choco install googlechrome -y
.\firefox.exe
choco install opera -y
choco install 7zip -y
choco install anydesk -y
choco install notepadplusplus -y
choco install far -y
choco install powershell-preview -y
.\Default.cmd
explorer.exe .\unkn0wn.theme
.\1803_VDI_Configuration.ps1
