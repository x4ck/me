wget "https://github.com/PowerShell/PowerShell/releases/download/v7.1.0-preview.1/PowerShell-7.1.0-preview.1-win-x64.msi" -O "PowerShell-7.1.0-preview.1-win-x64.msi"
.\PowerShell-7.1.0-preview.1-win-x64.msi ADD_EXPLORER_CONTEXT_MENU_OPENPOWERSHELL=1 ENABLE_PSREMOTING=1 REGISTER_MANIFEST=1
