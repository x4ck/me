choco install office365homepremium -y

