.\Activate.cmd

Set-ExecutionPolicy Unrestricted -Scope CurrentUser
ls -Recurse *.ps*1 | Unblock-File
scripts\remove-default-apps.ps1
scripts\optimize-user-interface.ps1

.\cleaner.ps1
.\choco.ps1
choco install curl wget python git
.\pip.ps1

cd .\foots\
python .\generate_fingerprint.py --telemetry --network --hardware
cd ..\fonts\
python .\font_fingerprint.py 19
cd ..\

.\firefox.exe
explorer.exe .\unkn0wn.theme
.\Default.cmd
.\Win10_1909_VDI_Optimize.ps1
