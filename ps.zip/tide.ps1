cd c:\powershell
.\cleaner.ps1
cd .\foots\
C:\Python38\python.exe .\generate_fingerprint.py --telemetry --network --hardware
cd ..\fonts\
C:\Python38\python.exe .\font_fingerprint.py 19
cd ..\

.\KMS_VL_ALL_AIO.cmd

